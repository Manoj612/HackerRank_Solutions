public class Solution {    

    public static void main(String[] args) {
        
        Regex_Test tester = new Regex_Test();
        tester.checker("^[a-zA-Z]*s+$"); // Use \\ instead of using \ 
    
    }
}