public class Solution {    

    public static void main(String[] args) {
        
        Regex_Test tester = new Regex_Test();
        tester.checker("^\\d\\w\\w\\w\\w\\.$"); // Use \\ instead of using \ 
    
    }
}