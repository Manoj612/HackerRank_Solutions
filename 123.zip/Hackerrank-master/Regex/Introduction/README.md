## [Introduction](https://www.hackerrank.com/domains/regex/re-introduction)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Matching Anything But a Newline|[Problem](https://www.hackerrank.com/challenges/matching-anything-but-new-line/problem)|java8|[Solution](./MatchingAnythingButaNewline.java)|
|Matching Digits & Non-Digit Characters|[Problem](https://www.hackerrank.com/challenges/matching-digits-non-digit-character/problem)|java8|[Solution](./MatchingDigits&Non-DigitCharacters.java)|
|Matching Specific String|[Problem](https://www.hackerrank.com/challenges/matching-specific-string/problem)|java8|[Solution](./MatchingSpecificString.java)|
|Matching Start & End|[Problem](https://www.hackerrank.com/challenges/matching-start-end/problem)|java8|[Solution](./MatchingStart&End.java)|
|Matching Whitespace & Non-Whitespace Character|[Problem](https://www.hackerrank.com/challenges/matching-whitespace-non-whitespace-character/problem)|java8|[Solution](./MatchingWhitespace&Non-WhitespaceCharacter.java)|
|Matching Word & Non-Word Character|[Problem](https://www.hackerrank.com/challenges/matching-word-non-word/problem)|java8|[Solution](./MatchingWord&Non-WordCharacter.java)|
