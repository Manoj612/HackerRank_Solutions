$Regex_Pattern = '/^\d\d(-|:|---|.)\d\d\1\d\d\1\d\d$/'; //Do not delete '/'. Replace __________ with your regex. 
