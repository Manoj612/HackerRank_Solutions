## [Backreferences](https://www.hackerrank.com/domains/regex/backreferences)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Backreferences To Failed Groups|[Problem](https://www.hackerrank.com/challenges/backreferences-to-failed-groups/problem)|java8|[Solution](./BackreferencesToFailedGroups.java)|
|Branch Reset Groups|[Problem](https://www.hackerrank.com/challenges/branch-reset-groups/problem)|php|[Solution](./branch-reset-groups.php)|
|Forward References|[Problem](https://www.hackerrank.com/challenges/forward-references/problem)|java8|[Solution](./ForwardReferences.java)|
|Matching Same Text Again & Again|[Problem](https://www.hackerrank.com/challenges/matching-same-text-again-again/problem)|java8|[Solution](./MatchingSameTextAgain&Again.java)|
