public class Solution {    

    public static void main(String[] args) {
        
        Regex_Test tester = new Regex_Test();
        tester.checker("^([a-z])([\\w])([\\s])([\\W])([\\d])([\\D])([A-Z])([A-Za-z])([aeiouAEIOU])([\\S])\\1\\2\\3\\4\\5\\6\\7\\8\\9\\10"); // Use \\ instead of using \ 
    
    }
}