public class Solution {    

    public static void main(String[] args) {
        
        Regex_Test tester = new Regex_Test();
        tester.checker("(ok){3,}"); // Use \\ instead of using \ 
    
    }
}