## [GroupingandCapturing](https://www.hackerrank.com/domains/regex/grouping-and-capturing)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Alternative Matching|[Problem](https://www.hackerrank.com/challenges/alternative-matching/problem)|java8|[Solution](./AlternativeMatching.java)|
|Capturing & Non-Capturing Groups|[Problem](https://www.hackerrank.com/challenges/capturing-non-capturing-groups/problem)|java8|[Solution](./Capturing&Non-CapturingGroups.java)|
|Matching Word Boundaries|[Problem](https://www.hackerrank.com/challenges/matching-word-boundaries/problem)|java8|[Solution](./MatchingWordBoundaries.java)|
