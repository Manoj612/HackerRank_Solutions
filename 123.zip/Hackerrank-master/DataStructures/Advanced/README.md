## [Advanced](https://www.hackerrank.com/domains/data-structures/data-structures)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Mr. X and His Shots|[Problem](https://www.hackerrank.com/challenges/x-and-his-shots/problem)|java|[Solution](./Mr.XandHisShots.java)|
