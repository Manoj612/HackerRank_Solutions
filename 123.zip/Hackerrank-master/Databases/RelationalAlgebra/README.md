## [RelationalAlgebra](https://www.hackerrank.com/domains/databases/relational-algebra)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Basics of Sets and Relations #1|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-1/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-1)|
|Basics of Sets and Relations #2|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-2/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-2)|
|Basics of Sets and Relations #3|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-3/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-3)|
|Basics of Sets and Relations #4|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-4/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-4)|
|Basics of Sets and Relations #5|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-5/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-5)|
|Basics of Sets and Relations #6|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-6/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-6)|
|Basics of Sets and Relations #7|[Problem](https://www.hackerrank.com/challenges/basics-of-sets-and-relational-algebra-7/problem)|text|[Solution](./basics-of-sets-and-relational-algebra-7)|
