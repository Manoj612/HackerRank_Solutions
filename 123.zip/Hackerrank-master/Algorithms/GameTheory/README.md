## [GameTheory](https://www.hackerrank.com/domains/algorithms/game-theory)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|A Chessboard Game|[Problem](https://www.hackerrank.com/challenges/a-chessboard-game-1/problem)|java|[Solution](./AChessboardGame.java)|
|Game of Stones|[Problem](https://www.hackerrank.com/challenges/game-of-stones-1/problem)|java|[Solution](./GameofStones.java)|
|Powers Game|[Problem](https://www.hackerrank.com/challenges/powers-game-1/problem)|java|[Solution](./PowersGame.java)|
|Tower Breakers |[Problem](https://www.hackerrank.com/challenges/tower-breakers-1/problem)|java|[Solution](./TowerBreakers.java)|
