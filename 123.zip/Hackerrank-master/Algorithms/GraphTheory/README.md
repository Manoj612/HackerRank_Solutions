## [GraphTheory](https://www.hackerrank.com/domains/algorithms/graph-theory)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Breadth First Search: Shortest Reach|[Problem](https://www.hackerrank.com/challenges/bfsshortreach/problem)|java8|[Solution](./BreadthFirstSearch:ShortestReach.java)|
|Dijkstra: Shortest Reach 2|[Problem](https://www.hackerrank.com/challenges/dijkstrashortreach/problem)|java|[Solution](./Dijkstra:ShortestReach2.java)|
