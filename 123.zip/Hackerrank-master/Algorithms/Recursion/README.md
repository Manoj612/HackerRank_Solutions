## [Recursion](https://www.hackerrank.com/domains/algorithms/recursion)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|The Power Sum|[Problem](https://www.hackerrank.com/challenges/the-power-sum/problem)|java|[Solution](./ThePowerSum.java)|
