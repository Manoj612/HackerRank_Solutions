## [Combinatorics](https://www.hackerrank.com/domains/mathematics/combinatorics)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Sherlock and Pairs|[Problem](https://www.hackerrank.com/challenges/sherlock-and-pairs/problem)|java8|[Solution](./SherlockandPairs.java)|
