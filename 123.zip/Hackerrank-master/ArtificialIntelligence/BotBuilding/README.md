## [BotBuilding](https://www.hackerrank.com/domains/ai/ai-introduction)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Bot saves princess|[Problem](https://www.hackerrank.com/challenges/saveprincess/problem)|java|[Solution](./Botsavesprincess.java)|
