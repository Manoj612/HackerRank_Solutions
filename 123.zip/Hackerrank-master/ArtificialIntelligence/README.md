## [ArtificialIntelligence](https://www.hackerrank.com/domains/ai)

|Subdomain|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---|---
|BotBuilding|Bot saves princess|[Problem](https://www.hackerrank.com/challenges/saveprincess/problem)|java|[Solution](BotBuilding/Botsavesprincess.java)|
