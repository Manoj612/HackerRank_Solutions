## [Others](https://www.hackerrank.com/domains/)

|Subdomain|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---|---
|Miscellaneous|Calculating Volume|[Problem](https://www.hackerrank.com/challenges/calculating-volume/problem)|java|[Solution](Miscellaneous/CalculatingVolume.java)|
|Miscellaneous|Counting Sort 3|[Problem](https://www.hackerrank.com/challenges/countingsort3/problem)|java|[Solution](Miscellaneous/CountingSort3.java)|
|Miscellaneous|Frequency Queries|[Problem](https://www.hackerrank.com/challenges/frequency-queries/problem)|java8|[Solution](Miscellaneous/FrequencyQueries.java)|
|Miscellaneous|Minimum Swaps 2|[Problem](https://www.hackerrank.com/challenges/minimum-swaps-2/problem)|java|[Solution](Miscellaneous/MinimumSwaps2.java)|
|Miscellaneous|Quicksort 2 - Sorting|[Problem](https://www.hackerrank.com/challenges/quicksort2/problem)|java8|[Solution](Miscellaneous/Quicksort2-Sorting.java)|
|Miscellaneous|Quicksort In-Place|[Problem](https://www.hackerrank.com/challenges/quicksort3/problem)|java8|[Solution](Miscellaneous/QuicksortIn-Place.java)|
