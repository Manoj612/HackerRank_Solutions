## [SQL](https://www.hackerrank.com/domains/sql)

|Subdomain|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---|---
|BasicSelect|Japanese Cities' Attributes|[Problem](https://www.hackerrank.com/challenges/japanese-cities-attributes/problem)|tsql|[Solution](BasicSelect/japanese-cities-attributes.sql)|
|BasicSelect|Japanese Cities' Names|[Problem](https://www.hackerrank.com/challenges/japanese-cities-name/problem)|tsql|[Solution](BasicSelect/japanese-cities-name.sql)|
|BasicSelect|Revising the Select Query II|[Problem](https://www.hackerrank.com/challenges/revising-the-select-query-2/problem)|tsql|[Solution](BasicSelect/revising-the-select-query-2.sql)|
|BasicSelect|Revising the Select Query I|[Problem](https://www.hackerrank.com/challenges/revising-the-select-query/problem)|tsql|[Solution](BasicSelect/revising-the-select-query.sql)|
|BasicSelect|Select All|[Problem](https://www.hackerrank.com/challenges/select-all-sql/problem)|tsql|[Solution](BasicSelect/select-all-sql.sql)|
|BasicSelect|Select By ID|[Problem](https://www.hackerrank.com/challenges/select-by-id/problem)|tsql|[Solution](BasicSelect/select-by-id.sql)|
|BasicSelect|Weather Observation Station 1|[Problem](https://www.hackerrank.com/challenges/weather-observation-station-1/problem)|tsql|[Solution](BasicSelect/weather-observation-station-1.sql)|
|BasicSelect|Weather Observation Station 3|[Problem](https://www.hackerrank.com/challenges/weather-observation-station-3/problem)|tsql|[Solution](BasicSelect/weather-observation-station-3.sql)|
|BasicSelect|Weather Observation Station 4|[Problem](https://www.hackerrank.com/challenges/weather-observation-station-4/problem)|tsql|[Solution](BasicSelect/weather-observation-station-4.sql)|
