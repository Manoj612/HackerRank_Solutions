## [BasicSelect](https://www.hackerrank.com/domains/sql/select)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Japanese Cities' Attributes|[Problem](https://www.hackerrank.com/challenges/japanese-cities-attributes/problem)|tsql|[Solution](./japanese-cities-attributes.sql)|
|Japanese Cities' Names|[Problem](https://www.hackerrank.com/challenges/japanese-cities-name/problem)|tsql|[Solution](./japanese-cities-name.sql)|
|Revising the Select Query II|[Problem](https://www.hackerrank.com/challenges/revising-the-select-query-2/problem)|tsql|[Solution](./revising-the-select-query-2.sql)|
|Revising the Select Query I|[Problem](https://www.hackerrank.com/challenges/revising-the-select-query/problem)|tsql|[Solution](./revising-the-select-query.sql)|
|Select All|[Problem](https://www.hackerrank.com/challenges/select-all-sql/problem)|tsql|[Solution](./select-all-sql.sql)|
|Select By ID|[Problem](https://www.hackerrank.com/challenges/select-by-id/problem)|tsql|[Solution](./select-by-id.sql)|
|Weather Observation Station 1|[Problem](https://www.hackerrank.com/challenges/weather-observation-station-1/problem)|tsql|[Solution](./weather-observation-station-1.sql)|
|Weather Observation Station 3|[Problem](https://www.hackerrank.com/challenges/weather-observation-station-3/problem)|tsql|[Solution](./weather-observation-station-3.sql)|
|Weather Observation Station 4|[Problem](https://www.hackerrank.com/challenges/weather-observation-station-4/problem)|tsql|[Solution](./weather-observation-station-4.sql)|
