static int temp=1;   
public static <T> void printArray(T[] a) {
    if(temp==2){
        
            System.out.println("Hello");
            System.out.println("World");
    }
        if(temp==1){
            System.out.println("1");
            System.out.println("2");
            System.out.println("3");
            temp++;
        }
    
    }