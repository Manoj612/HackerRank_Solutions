        /* Declare second integer, double, and String variables. */
int num=scan.nextInt();
System.out.println(num+i);
        /* Read and save an integer, double, and String to your variables.*/
Double n=scan.nextDouble();
System.out.println(n+d);
        /* Print the sum of both integer variables on a new line. */
String st=scan.nextLine();
st=scan.nextLine();
//System.out.println(st);
System.out.println(s+st);
        /* Print the sum of the double variables on a new line. */
		
        /* Concatenate and print the String variables on a new line; 
        	the 's' variable above should be printed first. */
