import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {

    public static void main(String[] args) {
        System.out.println("5");
        System.out.println("3 3");
        System.out.println("-1 0 1");
        System.out.println("4 2");
        System.out.println("-1 0 1 3");
        System.out.println("5 5");
        System.out.println("-1 0 -2 1 -3");
        System.out.println("6 2");
        System.out.println("-1 0 2 1 3 -2");
        System.out.println("7 7");
        System.out.println("-1 0 -2 -5 3 -3 -4");
    }
}
