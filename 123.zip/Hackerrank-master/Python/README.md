## [Python](https://www.hackerrank.com/domains/python)

|Subdomain|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---|---
|Introduction|Write a function|[Problem](https://www.hackerrank.com/challenges/write-a-function/problem)|python3|[Solution](Introduction/write-a-function.py)|
