## [Introduction](https://www.hackerrank.com/domains/python/py-introduction)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Write a function|[Problem](https://www.hackerrank.com/challenges/write-a-function/problem)|python3|[Solution](./write-a-function.py)|
