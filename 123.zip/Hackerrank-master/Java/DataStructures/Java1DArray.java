        // Declare array a here
int a[]=new int[n];
        for(int i = 0 ; i < n; i++){
            int val = scan.nextInt();
            // Fill array a here
            a[i]=val;
        }