## [ExceptionHandling](https://www.hackerrank.com/domains/java/handling-exceptions)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Java Exception Handling (Try-catch)|[Problem](https://www.hackerrank.com/challenges/java-exception-handling-try-catch/problem)|java|[Solution](./JavaExceptionHandling(Try-catch).java)|
|Java Exception Handling|[Problem](https://www.hackerrank.com/challenges/java-exception-handling/problem)|java|[Solution](./JavaExceptionHandling.java)|
