## [BigNumber](https://www.hackerrank.com/domains/java/bignumber)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Java BigDecimal|[Problem](https://www.hackerrank.com/challenges/java-bigdecimal/problem)|java8|[Solution](./JavaBigDecimal.java)|
|Java BigInteger|[Problem](https://www.hackerrank.com/challenges/java-biginteger/problem)|java|[Solution](./JavaBigInteger.java)|
|Java Primality Test|[Problem](https://www.hackerrank.com/challenges/java-primality-test/problem)|java|[Solution](./JavaPrimalityTest.java)|
