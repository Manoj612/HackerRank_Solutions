## [TerminologyandConcepts](https://www.hackerrank.com/domains/security/concepts)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Security - Message Space and Ciphertext Space|[Problem](https://www.hackerrank.com/challenges/security-message-space-and-ciphertext-space/problem)|java|[Solution](./Security-MessageSpaceandCiphertextSpace.java)|
|Security Encryption Scheme|[Problem](https://www.hackerrank.com/challenges/security-encryption-scheme/problem)|java|[Solution](./SecurityEncryptionScheme.java)|
|Security Key Spaces|[Problem](https://www.hackerrank.com/challenges/security-key-spaces/problem)|java|[Solution](./SecurityKeySpaces.java)|
