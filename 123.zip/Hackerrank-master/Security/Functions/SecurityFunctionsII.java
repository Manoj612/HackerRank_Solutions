/*
 * Complete the function below.
 */

    static int function(int x) {
        return x*x;
    }

