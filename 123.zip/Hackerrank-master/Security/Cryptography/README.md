## [Cryptography](https://www.hackerrank.com/domains/security/cryptography)

|Problem Name|Problem Link|Language|Solution Link|
---|---|---|---
|Keyword Transposition Cipher|[Problem](https://www.hackerrank.com/challenges/keyword-transposition-cipher/problem)|java|[Solution](./KeywordTranspositionCipher.java)|
|PRNG Sequence Guessing|[Problem](https://www.hackerrank.com/challenges/prng-sequence-guessing/problem)|java|[Solution](./PRNGSequenceGuessing.java)|
