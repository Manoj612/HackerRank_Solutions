read name
echo "Welcome $name"
