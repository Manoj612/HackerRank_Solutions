#!/bin/bash
x=1
while [ $x -le 99 ]
do
    echo $x
    x=$((x+2))
done
